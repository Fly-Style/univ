package AOP;

/**
 * @Author is flystyle
 * Created on 06.06.16.
 */
public interface SystemAction {
    String  makeRequest(int userId);
    void showAllTrains();
    void showTrains();
}
